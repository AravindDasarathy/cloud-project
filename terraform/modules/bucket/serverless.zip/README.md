# Serverless

This repo is created for maintaining google cloud function code.

## Pre-requisites
1. Node must be installed
2. NPM must be installed

## Installation steps
1. cd into the project.
2. Run `npm install` to install the repo's dependencies.